<form role="search" method="get" class="c-search" action="<?php echo home_url('/'); ?>">
    <div>
        <label for="s" class="visuallyhidden">Search for:</label>
        <input type="search" class="c-search__input" placeholder="Search DMD Pathfinders" name="s" value="" />

        <button type="submit" class="c-search__submit" >Submit</button>
    </div>
</form>