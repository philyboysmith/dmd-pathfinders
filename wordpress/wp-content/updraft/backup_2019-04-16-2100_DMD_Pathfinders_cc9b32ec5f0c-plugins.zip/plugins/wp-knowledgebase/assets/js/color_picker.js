jQuery(document).ready(function($){
    $('.cp-field').wpColorPicker();
});