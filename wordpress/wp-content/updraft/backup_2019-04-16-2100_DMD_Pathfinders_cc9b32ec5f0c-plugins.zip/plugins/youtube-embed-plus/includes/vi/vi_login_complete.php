<div class="ytvi-wrap">
    <div class="ytvi-login-complete">
        <?php include_once(EPYTVI_INCLUDES_PATH . 'vi_login_success_content.php'); ?>
    </div>
</div>
